# QuickPing
ExploreTogether ping feature remastered. ***WIP***

##Install Instruction
Works client-side only but must be installed on all clients if you want everyone able to see pinged objects.

## Features
- Use T (by default, see config) to ping what you point, name of pointed object/creature is displayed in the world and on the minimap to all players.
- Ping ores, berries, portals etc to add a pin on the map (TODO : Add a key to add any object on the map)
- Change text colors (chat, ping, shout, whisper, names) in config ***need improvement***

## Known issues
You can find the github at: https://github.com/Vodianoi/QuickPingMod
